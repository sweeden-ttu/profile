CCC -941

U.S. DEPARTMENT OF AGRICULTURE

(07-19-26)

Commodity Credit Corporation

## AVERAGE ADJUSTED GROSS INCOME (AGI) CERTIFICATION AND CONSENT TO DISCLOSURE OF TAX INFORMATION

INSTRUCTIONS: Please return completed form to FSA at the above address in box 1. In box 2, use the name and address recorded on the most recently filed tax return or IRS change of address notification.

2. Name and Address of Individual or Legal Entity (Including Zip Code)
3. Taxpayer Identification Number (TIN) (Social Security Number for Individual; or Employer Identification Number for Legal Entity)

## PART A - CERTIFICATION OF AVERAGE ADJUSTED GROSS INCOME

4. The program year for payment eligibility

- [ ] A. 20 Enter the year for which program benefits are requested. The period for calculation of the average AGI will be of the three taxable years preceding the most immediately preceding complete taxable year for which benefits are requested.

For example, the 3-year period for the calculation of the average AGI for 2026 would be the taxable years of 2022, 2023 and 2024.

5. I certify that the average adjusted gross income of the individual or legal entity in Item 2 (for the year included in Item4) was:

- [ ] A. Less than (or equal to) $900,000 More than $900,000

## PART B - CONSENT TO DISCLOSURE OF TAX INFORMATION

Pursuant to 26 U.S.C. §6103, I hereby authorize the Internal Revenue Service (IRS) to review the following items of "return information" (as defined in 26 U.S.C. §6103(b)(2)) from the returns (as specified below) of the individual or legal entity identified in Item 2 for the taxable years indicated in Item 4:

Form 1040 and 1040NR filers: farm income or loss; adjusted gross incomeForm 1120, 1120A, 1120C filers: charitable contributions, Form 1041 filers: farm income or loss, charitable contributions, income taxable income

distribution deductions, exemptions, adjusted total income; total income Form 1120S filers: Form 1065 filers: guaranteed payments to partners, ordinary business Form 990T: unrelated business taxable income

## income

I understand the IRS will review these items of return information in order to perform calculations, the results of which I authorize to be disclosed to officers and employees of the United States Department of Agriculture (USDA) for use in determining the individual's or legal entity's eligibility for specified payments for various commodity and conservation programs. The calculations performed by the IRS use a methodology prescribed by the USDA. In addition, I am aware that the USDA may use the information received for compliance purposes related to this eligibility determination, including referrals to the Department of Justice.

Specifically, the IRS will disclose to the USDA the individual's or legal entity's name and TIN, and inform the USDA if, pursuant to its calculations, the average Adjusted Gross Income (AGI) is above or below eligibility requirements as prescribed by the Agricultural Act of 2014 or Agriculture Improvement Act of 2018. The IRS will also disclose to the USDA the type of return from which the information used for the calculations was obtained.

If the IRS is unable to locate a return that matches the taxpayer identity information provided above, or if IRS records indicate that the speci-

fied return has not been filed, for any of the taxable years indicated, the IRS may disclose that it was unable to locate a return, or that a return was not filed, for those years, whichever is applicable.

I understand the Internal Revenue Code §6103(c), limits disclosure and use of return information provided pursuant to a taxpayer's consent and holds the recipient subject to penalties, brought by private right of action, for any unauthorized access, other use, or redisclosure without the taxpayer's express permission or request.

An approved Power of Attorney (Form FSA-211) on file with USDA cannot be used as evidence of signature authority when

## completingthis form.

## By signing this form:

- I acknowledge that I have read and reviewed all definitions and requirements on Page 2 of this form;
- I certify that all information contained within this certification is true and correct; and is consistent with the tax returns filed with the IRS;
- I agree to authorize CCC to obtain tax data from the IRS for AGI compliance verification purposes by filing this form;
- I am aware that without this consent to disclosure, the returns and return information of the individual or legal entity
- identified in Item 2 are confidential and are protected by law under the Internal Revenue Code;
- I certify that I am authorized under applicable state law to execute this consent on behalf of the legal entity identified in Item 2 (for legal entity only).
6. Signature (By)
7. Title/Relationship of the Individual if Signing in a Representative Capacity for a legal entity

DATE STAMP

8. Date (MM/DD/YYYY)

1. Return completed form to:

Privacy Act Statement: The following statement is made in accordance with the Privacy Act of 1974 (5 U.S.C. 552a - as amended). The authority for requesting the information identified on this form is Payment Limitation and Payment Eligibility (7 CFR Part 1400), the Commodity Credit Corporation Charter Act (15 U.S.C. 714 et seq.), the Agricultural Act of 2014 (7 U.S.C 9015), (Pub. L. 113-79), as amended by the Agriculture Improvement Act of 2018 (Pub. L. 115-334), the Further Continuing Appropriations and Other Extensions Act, 2024 (Pub. L. 11822), the American Relief Act, 2025 (Pub. L. 118-158), the One Big Beautiful Bill Act, 2025 (Pub. L. 119-21) and 7 CFR Part 1412.The informa-

tion will be used to determine eligibility for program benefits. The information collected on this form may be disclosed to other Federal, State, Local government agencies, Tribal agencies, and nongovernmental entities that have been authorized access to the information by statute or regulation and/or as described in applicable Routine Uses identified in the System of Records Notice for USD A/FSA-2, Farm Records File (Automated). Providing the requested information is voluntary. However, failure to furnish the requested information will result in a determination of ineligibility for program benefits.

Paperwork Reduction Act (PRA) Statement: This information collection is exempted from the Paperwork Reduction Act as specified in 7 U.S.C. 9091(c)(2)(B).

Public Burden Statement: For CFAP 2.0 and QLA only, public reporting burden for this collection is estimated to average 30 minutes per response, including reviewing instructions, gathering and maintaining the data needed, completing (providing the information), and reviewing the collection of information. You are not required to respond to the collection, or USDA may not conduct or sponsor a collection of information unless it displays a valid OMB control number. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden by emailing to: askusda@usda.gov (OMB NO. 0560-0297).

Non-Discrimination Statement: In accordance with Federal civil rights law and U.S. Department of Agriculture (USDA) civil rights regulations and policies, the USDA, its Agencies, offices, and employees, and institutions participating in or administering USDA programs are prohibited from discriminating based on race, color, national origin, religion, sex, disability, age, marital status, family/parental status, income derived from a public assistance program, political beliefs, or reprisal or retaliation for prior civil rights activity, in any program or activity conducted or funded by USDA (not all bases apply to all programs). Remedies and complaint filing deadlines vary by program or incident.

Persons with disabilities who require alternative means of communication for program information (e.g., Braille, large print, audiotape, American Sign Language, etc.) should contact the State or local Agency that administers the program or contact USDA through the Telecommunications Relay Service at 711 (voice and TTY). Additionally, program information may be made available in languages other than English.

To file a program discrimination complaint, complete the USDA Program Discrimination Complaint Form, AD-3027, found online at https://www.usda.gov/oascr/how-to-file-a-program-discrimination-complaint and at any USDA office or write a letter addressed to USDA and provide in the letter all of the information requested in the form. To request a copy of the complaint form, call (866) 632-9992. Submit your completed form or letter to USDA by: (1) mail: U.S. Department of Agriculture, Office of the Assistant Secretary for Civil Rights, 1400 Independence Avenue, SW, Mail Stop 9410, Washington, D.C. 20250-9410; (2) fax: (202) 690-7442; or (3) email: program.intake@usda.gov.

USDA is an equal opportunity provider, employer, and lender.

## GENERAL INFORMATION ON AVERAGE ADJUSTED GROSS INCOME - PART A

Individuals or legal entities that receive benefits under most programs administered by CCC cannot have incomes that exceed a certain limit set by law. For entities, both the entity itself, and its members cannot exceed the income limitation. If a member, whether an individual or an entity, of an entity exceeds the limitation, payments to that entity will be commensurately reduced according to that member's direct or indirect ownership share in the entity. (All members of the entity must also submit this form to verify income the limitation is met.)

Adjusted Gross Income is the individual's or legal entity's IRS-reported adjusted gross income consisting of both farm and nonfarm income. A three-year average of that income will be computed for the three years of the relevant base period identified on the first page of this form to determine eligibility for the applicable program year. Unless a specific exception applies, individuals or legal entities with average adjusted gross income greater than $900,000 shall be ineligible for all payments and benefits under the commodity, price support, disaster assistance, and conservation programs.

## HOW TO DETERMINE ADJUSTED GROSS INCOME (AGI)

Individual - Internal Revenue Service (IRS) Form 1040 filers, specific lines on that form represent the adjusted gross income and the income from farming, ranching, or forestry operations.

Trust or Estate - the adjusted gross income is the total income and charitable contributions reported to IRS.

C-Corporation and Limited Liability Company taxed as a C-Corporation-the adjusted gross income is the total of the final taxable income and any charitable contributions reported to IRS.

Tax-exempt Organization - the adjusted gross income is the unrelated business taxable income excluding any income from noncommercial activities as reported to the IRS.

## HOW TO DETERMINE AVERAGE ADJUSTED GROSS INCOME

The period for calculation of the average AGI will be of the three taxable years preceding the most immediately preceding complete taxable year for which benefits are requested. This table shows examples for applicable years to be used in determining average AGI.

|   IF the crop year is. . . | THEN. . .Average AGI will be based on the following years. . . .   |
|----------------------------|--------------------------------------------------------------------|
|                       2023 | 2021, 2020, and 2019                                               |
|                       2024 | 2022 , 2021 , and 2020                                             |
|                       2025 | 2023 , 2022 , and 2021                                             |
|                       2026 | 2024 , 2023 , and 2022                                             |
|                       2027 | 2025 , 2024 , and 2023                                             |

## GENERAL INFORMATION ON CONSENT TO DISCLOSURE OF TAX INFORMATION - PART B

This consent allows IRS's access to, and use of, certain items of return information to perform calculations, using a methodology prescribed by the USDA, that will assist USDA in its verification of a program participant's compliance with the adjusted gross income (AGI) limitations necessary for participation in, and receipt of, commodity, conservation, price support or disaster program benefits. This consent also permits the USDA to receive certain items of return information for its eligibility determination.

This consent authorizes the disclosure of these items of return information for only the specified time period. Each item of information requested on this form is needed for the IRS to (1) locate, and verify, your tax information; (2) perform the requisite Average AGI calculations; and (3) provide the USDA with the legal entity's name and Taxpayer Identification Number (TIN), the type of return from which the specified items were located for use in the calculation, and whether or not the average AGI is above or below eligibility requirements. The IRS will not provide the USDA with any of the items specified on this consent form that it uses to perform the calculations or the average AGI figure.

This form can only be signed by the person authorized under state law to sign this consent for the legal entity identified in Item 2. An approved Power of Attorney (Form FSA-211) on file with USDA cannot be used as evidence of signature authority when completing this form.

Internal Revenue Code, §6103(c), limits disclosure and use of return information received pursuant to the taxpayer's consent and holds the recipient subject to penalties for any unauthorized access, other use, or redisclosure without the taxpayer's express permission or request.

## INSTRUCTIONS FOR COMPLETION OF CCC-941

| Item No./Field name                          | Instruction                                                                                                                                                                                                                                                                             |
|----------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1. Return Completed Form To                  | Enter the name and address of the FSA county office or USDA service center where the completed CCC-941 will be submitted.                                                                                                                                                               |
| 2. Person or Legal Entity's Name and Address | Enter the person's or legal entity's name and address for commodity, conservation, price support, or disaster program benefits. Enter the name and address exactly as it appeared on the most recently filed IRS tax return or IRS change of address (Form 8822) .                      |
| 3. Taxpayer Identification Number            | In the format provided, enter the complete taxpayer identification number of the person or legal entity identified in Item 2. This will be either a Social Security Number or Taxpayer Identification Number .                                                                          |
| 4. Program Year                              | Enter the year for which program benefits are being requested. The program year entered determines the 3-year period used for the calculation of the average adjusted gross income (AGI) for payment eligibility and the years for which this consent allows access to tax information. |
| 5. Average Adjusted Gross Income             | Select the box next to the response that describes the average adjusted gross income for the applicable 3-year period for the program year entered in Item 4. Select only one response .                                                                                                |
| 6. Signature                                 | Read the acknowledgments, responsibilities and authorizations, before affixing your signature. Power of Attorney (Form FSA-211) on file with USDA cannot be used as evidence of signature authority .                                                                                   |
| 7. Title/Relationship                        | Enter title or relationship to the legal entity identified in Item 2, if applicable .                                                                                                                                                                                                   |
| 8. Date                                      | Enter the signature date in month, day and year. This form must be returned to FSA within 90 days of the signature date for the consent to be valid.                                                                                                                                    |