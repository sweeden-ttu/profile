AD-2047

(03-19-25)

## U.S. DEPARTMENT OF AGRICULTURE

Farm Service Agency Rural Development Natural Resources Conservation Service Risk Management Agency Agricultural Marketing Service

## CUSTOMER DATA WORKSHEET

NOTE: The following statement is made in accordance with the Privacy Act of 1974 (5 USC 552a - as amended). The authority for requesting the information identified on this form is the Computer Security Act of 1987 (Pub. L. 100-235), OMB Circular A-123, Federal Managers' Financial Integrity Act of 1982, and Privacy Act of 1974 (5 USC 552a - as amended). The information will be used to document a request by the producer for updating the business partner record. The information collected on this form may be disclosed to other Federal, State, Local government agencies, Tribal agencies, and nongovernmental entities that have been authorized access to the information by statute or regulation and/or as described in applicable Routine Uses identified in the System of Records Notices for AMS-3, Perishable Agricultural Commodities Act (PACA), USDA/FSA-2, Farm Records File (Automated), USDA/NRCS-1, Landowner, Operator, Producer, Cooperator, or Participant Files, and USDA/RD-1, Applicant, Borrower, Grantee, or Tenant File. Providing the requested information is voluntary. However, failure to furnish the requested information will result in a determination of ineligibility to request changes within the business partner record.

Public Burden Statement (Paperwork Reduction Act Statement): According to the Paperwork Reduction Act requirement, an agency may not conduct or sponsor, and a person is not required to respond to, a collection of information unless it displays a valid OMB control number. The valid OMB control number for this information collection is 0560-0265. The time required to complete this information collection is estimated to average 3 minutes (.05 hours) per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden by emailing to: askusda@usda.gov(Subject: OMB NO. 0560-0265).

The provisions of criminal and civil fraud, privacy and other statutes may be applicable to the information provided. RETURN THIS COMPLETED FORM TO YOUR COUNTY FSA OFFICE.

## PART A CUSTOMER INFORMATION

1. Reason for Request (Check appropriate box(es) below:)

- [ ] New Customer

- [ ] Update Existing Customer Record

- 2A. Customer's Full Name or Business Name and Address (Including Zip Code)
- 2B. Customer Business Type (Example: Individual, Corporation, LLC, Estate, Trust, etc.)
- 2C. Home Telephone Number (Area Code) 2D. Business Telephone Number (Area Code) 2E. Mobile Telephone Number (Area Code)
- 2F. Email Address
- 3A. Taxpayer Identification Number (Complete TIN for new customer or last 4 digits for existing customer) and Type (SSN, EIN, ITN, etc.)
- 3C. Citizenship Status: (For Individuals Only)

- [ ] U.S. Resident

- [ ] Resident Alien (I-551 Required)

- [ ] Not a US Citizen or Resident Alien

Citizenship country if not US:

## Demographic Information

Departmental Regulation 4370-001 provides USDA's policies for collecting demographic data, including race, ethnicity and sex. Providing demographic information is voluntary and at the discretion of the customer. Demographic information is used by USDA for statistical purposes only and will not be used to determine an applicant's eligibility for programs or services for which they apply. You may disregard providing information in items 4A, 4B or 4C if the information has previously been provided to USDA. A customer identified in Item 2A that is a legal entity must base responses to the race, ethnicity and sex on the individual persons holding at least 50 percent ownership interest in the legal entity.

- 4A. Race/Ethnicity: (Note: Select all that apply. )

- [ ] American Indian or Alaskan Native

- [ ] Asian

- [ ] Black or African American

- [ ] Hispanic or Latino

- [ ] Middle Eastern or North African

- [ ] Native Hawaiian or Pacific Islander

- [ ] White

Note: See instructions for legal entities

- 4B. Sex (Individual):

- [ ] Male

- [ ] Female

- 4C. Sex (Legal Entity)

- [ ] Not applicable/unknown

- [ ] Organization/Female Owned

- [ ] Organization/Male Owned

Date Stamp

- 2G. Does the customer want to receive sensitive (but non-PII) Producer or farm specific related emails?

- [ ] YES

- [ ] NO

- 3B. Birthdate (Only required if the customer is a minor)
- 3D. Originating Country (For Foreign Entities Only)

5. Customer has interest in one or more of the following agencies. (Check Appropriate Agency(ies) below:)

- [ ] AMS

- [ ] FSA

- [ ] NRCS

- [ ] RMA

- [ ] RD

6. Is the Customer a Multi-County Producer?

- [ ] YES (If "YES," list States and/or Counties below:)

- [ ] NO

7. See form instructions for signature requirements.
- 7A. Customer Signature
- 7B. Title/Relationship
- 7C. Date (MM-DD-YYYY)

## PART B SERVICE CENTER ACTION

- 8A. Agency Who Received Request: (Check one below)

- [ ] FSA

- [ ] NRCS

- [ ] RD

9. How the Request for Change was Received:

- [ ] Office Visit Telephone

- [ ] FAX

- 8B. Initials of Employee Receiving

Request (If Different than Item 12A)

- [ ] USPS

- 8C. Date Service Center Employee

Received the Request (MM-DD-YYYY)

- [ ] Box One Span Other (Specify):

10. COC LAA:
11. Remarks, if Applicable:
- 12A. Signature of Employee Updating Business Partner if not initialed in Item 8B.
- 12B. Date Service Center Employee Updating Business Partner (MM-DD-YYYY)

Non-Discrimination Statement: In accordance with Federal civil rights law and U.S. Department of Agriculture (USDA) civil rights regulations and policies, the USDA, its Agencies, offices, and employees, and institutions participating in or administering USDA programs are prohibited from discriminating based on race, color, national origin, religion, sex, disability, age, marital status, family/parental status, income derived from a public

assistance program, political beliefs, or reprisal or retaliation for prior civil rights activity, in any program or activity conducted or funded by USDA (not all bases apply to all programs). Remedies and complaint filing deadlines vary by program or incident.

Persons with disabilities who require alternative means of communication for program information (e.g., Braille, large print, audiotape, American Sign Language, etc.) should contact the State or local Agency that administers the program or contact USDA through the Telecommunications Relay Service at 711 (voice and TTY). Additionally, program information may be made available in languages other than English.

To file a program discrimination complaint, complete the USDA Program Discrimination Complaint Form, AD-3027, found online at http://www.ascr.usda.gov/complaint\_filing\_cust.html and at any USDA office or write a letter addressed to USDA and provide in the letter all of the information requested in the form. To request a copy of the complaint form, call (866) 632-9992. Submit your completed form or letter to USDA by: (1) mail: U.S. Department of Agriculture, Office of the Assistant Secretary for Civil Rights, 1400 Independence Avenue, SW, Mail Stop 9410, Washington, D.C. 20250-9410; (2) fax: (202) 690-7442; or (3) email:program.intake@usda.gov.

USDA is an equal opportunity provider, employer, and lender.