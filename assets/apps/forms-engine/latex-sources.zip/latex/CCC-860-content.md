CCC-860

(01-11-23)

## U.S. DEPARTMENT OF AGRICULTURE

Commodity Credit Corporation OMB Control Number/Expiration date: 0560-0297 and 09/30/2024 OMB Control Number/Expiration date: 0560-0309 and 12/31/2025 OMB Control Number/Expiration date: 0560-0311 and 12/31/2024

- 1A. County FSA Office Name and Address (Including Zip Code)

## SOCIALLY DISADVANTAGED, LIMITED RESOURCE, BEGINNING AND VETERAN FARMER OR RANCHER CERTIFICATION

2. Applicant's Name and Address

&amp;

4

INFORMATION:

\_

- 1B. peti sd ine
- 1C. Program Year

INSTRUCTIONS:

Complete Parts A, B, C D, and/or E as applicable. Read the information relating to false certification in Part F. Return this form to the address in Item 1 above.

If a legal entity requests to be considered a "socially disadvantaged," "limited resource," "beginning" or "veteran" farmer or rancher, the entity must meet the definition as provided on Page 2 of this form. Farmer or rancher includes; "owners", "operators" and "other producers".

## PART A — CERTIFICATION OF SOCIALLY DISADVANTAGED FARMER OR RANCHER

3. I certify that I am a member of a group listed below, whose members have been subject to racial, ethnic, or gender prejudice because of their identity as members of a group without regard to their individual qualities. (Check all that apply apply but note that if only "women" is checked without selecting the other category, the selection does not make the applicant socially disadvantaged for conservation programs).

- [ ] [\_] Women.

- [ ] American Indians or Alaskan Natives, Asians or Asian Americans, Black or African Americans, Native Hawaiians or other Pacific Islanders, Hispanics.

## PART B — CERTIFICATION OF LIMITED RESOURCE FARMER OR RANCHER

Limited resource farmer or rancher status can be determined by using a web site available through the Limited Resource Farmer and Rancher Online Self-Determination Tool through Natural Resources Conservation Service at https://Irfiool.sc.egov.usda.gov/.

- [ ] fi] 4. I certify that the following statements are true by checking the box:

My/our direct or indirect gross farm sales (as individuals, if applicable for the entity or joint operation) do not exceed the amount identified in the Limited Resource Farmer/Rancher Self-Determination Tool for the 2 calendar years that precede the complete taxable year before the relevant program year (see Table 1 on Page 2 of this form), adjusted upwards in later years for any general inflation.

My/our total household income (as individuals, if applicable for the entity or joint operation) was at or below the national poverty level for a family of four in each of the same 2 previous years (see Table | on Page 2 of this form) referenced above.

## PART C — CERTIFICATION OF BEGINNING FARMER OR RANCHER

- [ ] &amp; 5. I certify that the following statements are true by checking the box and providing the date I began farming:

I (or if applicable, the entity or joint operation) have not operated a farm or ranch for more than 10 years.

I (or if applicable, the entity or joint operation) substantially participate in the operation.

Date (Month/Year began farming)

## PART D — CERTIFICATION OF VETERAN FARMER OR RANCHER

6. I certify that I am a farmer or rancher who has served in the Armed Forces as defined in 38 U.S.C. 101(10) and I meet the requirements of at least one of the boxes below: (Check all that apply)

- [ ] 3 A. I (or if applicable, the entity or joint operation) have not operated a farm or ranch for more than 10 years and began farming in

Date (Month/Year)

- [ ] | B. I (or if applicable, the entity or joint operation) am a veteran (as defined in 38 U.S.C. 101(2)) who first obtained status as a veteran during the most recent 10-year period

Date (Month/Year)

## PART E —- NAP COVERAGE OPTION

By submitting a certification under Parts A, B, C, and/or D, you are also certifying that you are eligible for a service fee waiver for catastrophic coverage on eligible crops under the Noninsured Crop Disaster Assistance Program (NAP) for each program year for which your certification is applicable. Additionally, higher levels of NAP coverage can be purchased with reduced premiums through your local FSA County Office. NAP is subject to 7 CFR Part 1437 and the NAP Basic Provisions, available at: https://www.fsa.usda.gov/programsand-services/disaster-assistance-program/noninsured-crop-disaster-assistance/index

Your signature on this certification is your application for NAP catastrophic coverage, and acknowledgement and receipt of the NAP Basic Provisions, on eligible crops for each program year for which your certification is applicable, unless you opt out of NAP catastrophic coverage for eligible crops in Item 7 below. For more information about NAP, visit your local FSA County office.

- [ ] 7. If you do not want to participate in NAP, enter a check mark in the box provided. | elect to opt out of NAP coverage fa]

## PART F — PENALTY FOR FALSE CERTIFICATION

The penalty for false certification is loss of all benefits for the crop year in which the false certification was made.

- 8A. Applicant's Signature (By)

NOTE:

- 8B. Title/Relationship of the Individual Signing in the Representative Capacity
- 8C. Date (MM-DD-YYYY)

The following statement is made in accordance with the Privacy Act of 1974 (5 USC 552a — as amended). The authority for requesting the information identified on this form is the Commodity Credit Corporation Charter Act (15 U.S.C. 714 et seq.) and the Agricultural Act of 2014 (Pub. L. 113-79). The information will be used to certify that an individual, legal entity, or joint operation is a member of a socially disadvantaged group, qualifies as a limited resource CCC producer, qualifies as a beginning farmer or rancher or qualifies as a veteran farmer or rancher. The information collected on this form may be disclosed to other Federal, State, Local government agencies, Tribal agencies, and nongovernmental entities that have been authorized access to the information by statute or regulation and/or as described in applicable Routine Uses identified in the System of Records Notice for USDA/FSA-2, Farm Records File (Automated) and USDA/FSA-14, Applicant/Borrower. Providing the requested information is voluntary. However, failure to furnish the requested information will result in a determination of ineligibility for socially disadvantaged, limited resource, or beginning farmer or rancher program benefits.

Paperwork Reduction Act (PRA) Statement: Information collection is exempted from PRA as specified in 7 U.S.C. 9091(c)(2)(B).

Public Burden Statement (Paperwork Reduction Act): Public reporting burden for this collection is estimated to average 6 minutes per response, including reviewing instructions, gathering and maintaining the data needed, completing (providing the information), and reviewing the collection of information. For the CFAP, ERP Phase 1 and 2, and FSCSC, you are not required to respond to this collection of information unless valid OMB control numbers are displayed.

In accordance with Federal civil rights law and U.S. Department of Agriculture (USDA) civil rights regulations and policies, the USDA, its Agencies, offices, and employees, and institutions participating in or administering USDA programs are prohibited from discriminating based on race, color, national origin, religion, sex, gender identity (including gender expression), sexual orientation, disability, age, marital status, family/parental status, income derived from a public assistance program, political beliefs, or reprisal or retaliation for prior civil rights activity, in any program or activity conducted or funded by USDA (not all bases apply to all programs). Remedies and complaint filing deadlines vary by program or incident.

Persons with disabilities who require alternative means of communication for program information (e.g., Braille, large print, audiotape, American Sign Language, etc.) should contact the responsible Agency or USDA's TARGET Center at (202) 720-2600 (voice and TTY) or contact USDA through the Federal Relay Service at (800) 877-8339. Additionally, program information may be made available in languages other than English.

To file a program discrimination complaint, complete the USDA Program Discrimination Complaint Form, AD-3027, found online at http://www. ascr.usda.gov/complaint\_filing\_cust.html and at any USDA office or write a letter addressed to USDA and provide in the letter all of the information requested in the form. To request a copy of the complaint form, call (866) 632-9992. Submit your completed form or letter to USDA by: (1) mail: U.S. Department of Agriculture Office of the Assistant Secretary for Civil Rights 1400 Independence Avenue, SW Washington, D.C. 20250-9410; (2) fax: (202) 690-7442; or (3) email: program.intake@usda.gov. USDA is an equal opportunity provider, employer, and lender.

## A. Socially Disadvantaged Farmer or Rancher:

A socially disadvantaged farmer or rancher is a farmer or rancher who is a member of a group whose members have been subject to racial, ethnic, or gender prejudice because of their identity as members of a group without regard to their individual qualities. Groups include: American Indians or Alaskan Natives, Asians or Asian Americans, Blacks or African Americans, Native Hawaiians or other Pacific Islanders, Hispanics, and women (for those selecting a group that includes gender). Note that if applicant only checks "women" without also selecting the other category the selection does not make applicant socially disadvantaged for conservation programs.

For entities requesting to be considered socially disadvantaged, at least 50% of the interest must be held by socially disadvantaged individuals.

## B. Limited Resource Farmer or Rancher:

A limited resource farmer or rancher is a farmer or rancher that meets the criteria for both of the following:

- e A producer whose direct or indirect gross farm sales do not exceed the amount identified in the Limited Resource Farmer/Rancher Self-Determination Tool* in each of the 2 calendar years that precede the complete taxable year before the relevant program year, adjusted upwards in later years for any general inflation, and
- e A producer whose total household income was at or below the national poverty level for a family of four in each of the same 2 previous years reference in paragraph (1) of this definition.
* A limited resource farmer or rancher status can be determined using the web site available through the Limited Resource Farmer and Rancher Online Self-Determination Tool through Natural Resources Conservation Service at /ittps://Irfiool.sc.egov.usda.gov/.

|   Table 1: Direct and Indirect Gross Sales | Table 1: Direct and Indirect Gross Sales   |
|--------------------------------------------|--------------------------------------------|
|                                            | Corresponding Years &#124;                 |
|                                            | 2014 and 2015 &#124; &#124;                |
|                                       2018 | &#124; &#124; 2015 and 2016                |
|                                       2019 | &#124; 2016 and 2017                       |
|                                       2020 | &#124; 2017 and 2018                       |

For entities requesting to be considered limited resource farmer or rancher, all members must be a limited resource farmer or rancher.

Note: This definition is not applicable to Farm Loan Programs.

## C. Beginning Farmer or Rancher:

A beginning farmer or rancher is a person or legal entity for which both of the following are true for the farmer or rancher:

- e — Has not operated a farm or ranch for more than 10 years, and
- e = Materially and substantially participates in the operation.

For entities to be considered a beginning farmer or rancher, at least 50% of the interest must be beginning farmers or ranchers.

NOTE: This definition is not inclusive of all Farm Loan Programs requirements.

## D. Veteran Farmer or Rancher:

A veteran farmer or rancher is a farmer or rancher who has served in the Armed Forces (as defined in section 101 (10) of title 38) and who —

- e — Has not operated a farm or ranch for more than 10 years total, or
- e Has obtained status as a veteran (as so defined in 38 U.S.C. 101(2)) during the most recent 10-year period.

For entities requesting to be considered a veteran farmer or rancher, at least 50% of the interest must be held by veteran farmers or ranchers.

## Definitions:

## E. NAP Coverage Option:

The Noninsured Crop Disaster Assistance Program (NAP) provides financial assistance to producers of non-insurable crops when a low yield, loss of inventory, or prevented planting occurs due to natural disasters. Non-insurable crops are those not insured by the Federal Crop Insurance Corporation. Eligible crops for NAP are commercially grown for food or fiber (excluding livestock and their by-products), commodities, and industrial crops for which crop insurance, excluding pilot coverage, is not available.

Catastrophic coverage is equal to 50 percent of your expected yield and 55 percent of the expected price for the eligible crop (referred to as Basic 50/55). You are not required to pay a fee or a premium for this level of coverage. Additional coverage options and higher levels of coverage are available with a premium. To avail yourself to these options, you must timely file CCC-471 (NAP Application for Coverage) in any FSA County office.

For additional information regarding NAP, visit FSA's NAP page at:

https://www.fsa.usda.gov/programs-and-services/disaster-assistance-program/noninsured-crop-disaster-assistance/index