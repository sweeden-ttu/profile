using System;
using System.Collections.Generic;
using System.Linq;

namespace KnapsackAnalysis
{
    /// <summary>
    /// Enhanced main program with data export for visualization
    /// Deliverable 1, 2, and 3: Complete data collection pipeline
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("CS 5381 - Analysis of Algorithms");
            Console.WriteLine("Assignment 2: Complete Knapsack Analysis with Data Export");
            Console.WriteLine(new string('=', 70));
            Console.WriteLine();

            try
            {
                // Clear any previous data
                DataExporter.ClearData();

                // Run all analysis phases
                RunCorrectnessTests();
                RunComplexityVerification();
                RunPerformanceAnalysis(); // New: Extended performance tests
                RunLargeInstanceTests(); // New: Multiple large instances
                RunPseudopolynomialTests();
                
                // Export data for visualization
                ExportDataForVisualization();

                Console.WriteLine();
                Console.WriteLine(new string('=', 70));
                Console.WriteLine("🎉 ALL ANALYSIS COMPLETED SUCCESSFULLY!");
                Console.WriteLine("✅ Deliverable 1: Implementation and verification complete");
                Console.WriteLine("✅ Deliverable 2: Normal input performance data collected");
                Console.WriteLine("✅ Deliverable 3: Special input performance data collected");
                Console.WriteLine("📊 Data exported for Python visualization");
                Console.WriteLine(new string('=', 70));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ ERROR: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }

            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
        }

        static void RunCorrectnessTests()
        {
            Console.WriteLine("PHASE 1: CORRECTNESS VERIFICATION");
            Console.WriteLine(new string('=', 50));
            Console.WriteLine();

            var testCases = GetTestCases();

            foreach (var testCase in testCases)
            {
                Console.WriteLine($"Testing: {testCase.Description}");
                Console.WriteLine($"  Weights: [{string.Join(", ", testCase.Weights)}]");
                Console.WriteLine($"  Values:  [{string.Join(", ", testCase.Values)}]");
                Console.WriteLine($"  Capacity: {testCase.Capacity}");

                var buSolver = new KnapsackBottomUp();
                var tdSolver = new KnapsackTopDown();
                var buResult = buSolver.Solve(testCase.Weights, testCase.Values, testCase.Capacity);
                var tdResult = tdSolver.Solve(testCase.Weights, testCase.Values, testCase.Capacity);

                bool isCorrect = buResult.MaxValue == tdResult.MaxValue;

                Console.WriteLine($"  Results: BU={buResult.MaxValue}, TD={tdResult.MaxValue} ✅");

                // Record data for export
                DataExporter.RecordExperiment(
                    testCase.Description,
                    testCase.Weights.Length,
                    testCase.Capacity,
                    buResult,
                    tdResult,
                    isCorrect
                );

                if (!isCorrect)
                {
                    throw new Exception($"Correctness test failed: {testCase.Description}");
                }

                Console.WriteLine();
            }

            Console.WriteLine("✅ All correctness tests passed!\n");
        }

        static void RunComplexityVerification()
        {
            Console.WriteLine("PHASE 2: COMPLEXITY VERIFICATION");
            Console.WriteLine(new string('=', 50));
            Console.WriteLine();

            var complexityTests = new[]
            {
                new { n = 5, W = 10, description = "Small" },
                new { n = 8, W = 15, description = "Medium" },
                new { n = 12, W = 25, description = "Large" },
                new { n = 15, W = 30, description = "XLarge" }
            };

            Console.WriteLine("Size | n×W | BU Ops | TD Ops | BU Ratio | TD Ratio | BU Time | TD Time | Speedup");
            Console.WriteLine(new string('-', 85));

            foreach (var test in complexityTests)
            {
                var random = new Random(42);
                var weights = Enumerable.Range(0, test.n).Select(_ => random.Next(1, test.W / 2)).ToArray();
                var values = Enumerable.Range(0, test.n).Select(_ => random.Next(1, 100)).ToArray();

                var buSolver = new KnapsackBottomUp();
                var tdSolver = new KnapsackTopDown();
                var resultBU = buSolver.Solve(weights, values, test.W);
                var resultTD = tdSolver.Solve(weights, values, test.W);

                long expectedOps = (long)test.n * test.W;
                double buRatio = (double)resultBU.OperationCount / expectedOps;
                double tdRatio = (double)resultTD.OperationCount / expectedOps;
                double speedup = resultBU.ExecutionTimeMs / resultTD.ExecutionTimeMs;

                Console.WriteLine($"{test.description,-5} | {expectedOps,3} | {resultBU.OperationCount,6} | {resultTD.OperationCount,6} | " +
                                $"{buRatio,8:F3} | {tdRatio,8:F3} | {resultBU.ExecutionTimeMs,7:F2} | {resultTD.ExecutionTimeMs,7:F2} | {speedup,7:F2}x");

                // Record for export
                DataExporter.RecordExperiment(
                    $"Complexity_{test.description}",
                    test.n,
                    test.W,
                    resultBU,
                    resultTD,
                    true
                );

                // Clear console output for large instances
                if (expectedOps > 200)
                {
                    Console.Clear();
                    Console.WriteLine($"Completed complexity test: {test.description} (n={test.n}, W={test.W})");
                }
            }

            Console.WriteLine("\n✅ Complexity verification complete!\n");
        }

        static void RunPerformanceAnalysis()
        {
            Console.WriteLine("PHASE 3: PERFORMANCE ANALYSIS (DELIVERABLE 2 & 3)");
            Console.WriteLine(new string('=', 50));
            Console.WriteLine();

            // Deliverable 2: Normal inputs (weights = 1 to W)
            Console.WriteLine("🔍 DELIVERABLE 2: Normal Input Performance");
            Console.WriteLine("Weights: Random(1, W)");
            Console.WriteLine();

            RunPerformanceTests("Normal", useSpecialWeights: false);

            Console.WriteLine();

            // Deliverable 3: Special inputs (weights = 1 to 10)
            Console.WriteLine("🔍 DELIVERABLE 3: Special Input Performance");
            Console.WriteLine("Weights: Random(1, 10) - Low weights");
            Console.WriteLine();

            RunPerformanceTests("Special", useSpecialWeights: true);

            Console.WriteLine("✅ Performance analysis complete!\n");
        }

        static void RunPerformanceTests(string testType, bool useSpecialWeights)
        {
            var random = new Random(123);

            // Test various combinations of n and W
            var testConfigs = new[]
            {
                // Runtime vs n (fixed W)
                new { n = 5, W = 20, category = "vs_n" },
                new { n = 10, W = 20, category = "vs_n" },
                new { n = 15, W = 20, category = "vs_n" },
                new { n = 20, W = 20, category = "vs_n" },
                new { n = 25, W = 20, category = "vs_n" },
                
                // Runtime vs W (fixed n)
                new { n = 15, W = 10, category = "vs_W" },
                new { n = 15, W = 20, category = "vs_W" },
                new { n = 15, W = 40, category = "vs_W" },
                new { n = 15, W = 60, category = "vs_W" },
                new { n = 15, W = 80, category = "vs_W" }
            };

            Console.WriteLine("Config | n | W | BU Time | TD Time | Speedup | Cache Hit% | Table Util%");
            Console.WriteLine(new string('-', 75));

            foreach (var config in testConfigs)
            {
                // Generate instance based on weight strategy
                int[] weights;
                if (useSpecialWeights)
                {
                    // Special: weights 1-10 only
                    weights = Enumerable.Range(0, config.n).Select(_ => random.Next(1, 11)).ToArray();
                }
                else
                {
                    // Normal: weights 1-W
                    weights = Enumerable.Range(0, config.n).Select(_ => random.Next(1, config.W)).ToArray();
                }

                var values = Enumerable.Range(0, config.n).Select(_ => random.Next(1, 200)).ToArray();

                var buSolver = new KnapsackBottomUp();
                var tdSolver = new KnapsackTopDown();
                var resultBU = buSolver.Solve(weights, values, config.W); // or test.W
                var resultTD = tdSolver.Solve(weights, values, config.W);

                double speedup = resultBU.ExecutionTimeMs / resultTD.ExecutionTimeMs;

                Console.WriteLine($"{config.category,-6} | {config.n,2} | {config.W,2} | {resultBU.ExecutionTimeMs,7:F3} | " +
                                $"{resultTD.ExecutionTimeMs,7:F3} | {speedup,7:F2}x | {resultTD.CacheHitRate,9:F1}% | {GetTableUtilization(resultTD),10:F1}%");

                // Record for export
                DataExporter.RecordExperiment(
                    $"{testType}_{config.category}",
                    config.n,
                    config.W,
                    resultBU,
                    resultTD,
                    true
                );

                // Clear console for large instances
                if (config.n * config.W > 500)
                {
                    Console.Clear();
                    Console.WriteLine($"Completed {testType} test: n={config.n}, W={config.W}");
                }
            }
        }

        static void RunLargeInstanceTests()
        {
            Console.WriteLine("PHASE 4: LARGE INSTANCE SCALABILITY");
            Console.WriteLine(new string('=', 50));
            Console.WriteLine();

            var largeTests = new[]
            {
                new { n = 30, W = 50, description = "Large_1" },
                new { n = 25, W = 80, description = "Large_2" },
                new { n = 40, W = 40, description = "Large_3" }
            };

            foreach (var test in largeTests)
            {
                Console.WriteLine($"Testing large instance: {test.description} (n={test.n}, W={test.W})");

                var random = new Random(456);
                var weights = Enumerable.Range(0, test.n).Select(_ => random.Next(1, test.W / 3)).ToArray();
                var values = Enumerable.Range(0, test.n).Select(_ => random.Next(1, 300)).ToArray();

                Console.WriteLine("  Running algorithms...");

                var buSolver = new KnapsackBottomUp();
                var tdSolver = new KnapsackTopDown();
                var resultBU = buSolver.Solve(weights, values, test.W);
                var resultTD = tdSolver.Solve(weights, values, test.W);

                Console.WriteLine($"  Results: Both found value {resultBU.MaxValue}");
                Console.WriteLine($"  Performance: BU={resultBU.ExecutionTimeMs:F2}ms, TD={resultTD.ExecutionTimeMs:F2}ms");
                Console.WriteLine($"  Speedup: {resultBU.ExecutionTimeMs / resultTD.ExecutionTimeMs:F2}x");
                Console.WriteLine();

                // Record for export
                DataExporter.RecordExperiment(
                    test.description,
                    test.n,
                    test.W,
                    resultBU,
                    resultTD,
                    resultBU.MaxValue == resultTD.MaxValue
                );
            }

            Console.WriteLine("✅ Large instance testing complete!\n");
        }

        static void RunPseudopolynomialTests()
        {
            Console.WriteLine("PHASE 6: PSEUDOPOLYNOMIAL DEMO");
            var tdSolver = new KnapsackTopDown();
            var buSolver = new KnapsackBottomUp();
            var rand = new Random(2025);
            int n = 20;

            for (int k = 8; k <= 16; k++)
            {
                int W = 1 << k;
                var weights = Enumerable.Range(0, n).Select(_ => rand.Next(1, 11)).ToArray(); // small weights
                var values = Enumerable.Range(0, n).Select(_ => rand.Next(1, 101)).ToArray();

                var resultBU = buSolver.Solve(weights, values, W);
                var resultTD = tdSolver.Solve(weights, values, W);

                DataExporter.RecordExperiment($"Pseudo_{k}", n, W, resultBU, resultTD, true);
            }
        }

        static void ExportDataForVisualization()
        {
            Console.WriteLine("PHASE 5: DATA EXPORT FOR VISUALIZATION");
            Console.WriteLine(new string('=', 50));
            Console.WriteLine();

            // Export to multiple formats
            DataExporter.ExportToCSV("knapsack_results.csv");
            DataExporter.ExportToJSON("knapsack_results.json");
            DataExporter.GenerateSummaryReport("performance_summary.txt");

            Console.WriteLine();
            Console.WriteLine("📊 VISUALIZATION INSTRUCTIONS:");
            Console.WriteLine("Run the following command to generate all plots:");
            Console.WriteLine("  python knapsack_visualizer.py knapsack_results.csv");
            Console.WriteLine();
            Console.WriteLine("This will create:");
            Console.WriteLine("  📈 deliverable2_runtime_vs_n.png");
            Console.WriteLine("  📈 deliverable2_runtime_vs_w.png");
            Console.WriteLine("  📈 deliverable3_efficiency.png");
            Console.WriteLine("  📈 algorithm_comparison.png");
        }

        static double GetTableUtilization(KnapsackResult result)
        {
            if (result.MemoTable == null)
                return 0;

            int rows = result.MemoTable.GetLength(0);
            int cols = result.MemoTable.GetLength(1);
            int computedEntries = 0;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (result.MemoTable[i, j] != -1)
                        computedEntries++;
                }
            }

            return (double)computedEntries / (rows * cols) * 100;
        }

        static List<TestCase> GetTestCases()
        {
            return new List<TestCase>
            {
                new TestCase
                {
                    Description = "Class_Example",
                    Weights = new[] { 7, 3, 4, 5 },
                    Values = new[] { 42, 12, 40, 25 },
                    Capacity = 10
                },
                new TestCase
                {
                    Description = "Simple_Case",
                    Weights = new[] { 1, 2, 3 },
                    Values = new[] { 10, 20, 30 },
                    Capacity = 5
                },
                new TestCase
                {
                    Description = "Single_Item",
                    Weights = new[] { 5 },
                    Values = new[] { 100 },
                    Capacity = 10
                },
                new TestCase
                {
                    Description = "No_Items_Fit",
                    Weights = new[] { 10, 20, 30 },
                    Values = new[] { 60, 100, 120 },
                    Capacity = 5
                },
                new TestCase
                {
                    Description = "All_Items_Fit",
                    Weights = new[] { 1, 2, 3 },
                    Values = new[] { 10, 20, 30 },
                    Capacity = 10
                },
                new TestCase
                {
                    Description = "Equal_Values",
                    Weights = new[] { 2, 3, 4, 5 },
                    Values = new[] { 50, 50, 50, 50 },
                    Capacity = 8
                },
                new TestCase
                {
                    Description = "Zero_Capacity",
                    Weights = new[] { 1, 2, 3 },
                    Values = new[] { 10, 20, 30 },
                    Capacity = 0
                }
            };
        }

        public class TestCase
        {
            public string Description { get; set; } = string.Empty;
            public int[] Weights { get; set; } = Array.Empty<int>();
            public int[] Values { get; set; } = Array.Empty<int>();
            public int Capacity { get; set; }
        }
    }
}