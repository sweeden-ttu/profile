namespace KnapsackAnalysis
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Unified result structure used by both TopDown and BottomUp Knapsack algorithms
    /// </summary>
    public class KnapsackResult
    {
        public int MaxValue { get; set; }
        public List<int> OptimalItems { get; set; } = new List<int>();
        public long OperationCount { get; set; }
        public double ExecutionTimeMs { get; set; }

        // Top-down only
        public long RecursiveCalls { get; set; }
        public long CacheHits { get; set; }
        public int[,]? MemoTable { get; set; }

        // Bottom-up only
        public int[,]? DpTable { get; set; }

        public double CacheHitRate => RecursiveCalls > 0 ? (double)CacheHits / RecursiveCalls * 100 : 0;

        public int TableUtilization
        {
            get
            {
                var table = MemoTable ?? DpTable;
                if (table == null) return 0;
                int rows = table.GetLength(0);
                int cols = table.GetLength(1);
                int used = 0;
                for (int i = 0; i < rows; i++)
                    for (int j = 0; j < cols; j++)
                        if (table[i, j] != -1) used++;
                return (int)((double)used / (rows * cols) * 100);
            }
        }
    }

    /// <summary>
    /// Shared interface for Knapsack solvers
    /// </summary>
    public interface IKnapsackSolver
    {
        KnapsackResult Solve(int[] weights, int[] values, int capacity);
    }
}
