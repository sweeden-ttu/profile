using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace KnapsackAnalysis
{
    /// <summary>
    /// Top-down dynamic programming solution for the 0/1 Knapsack problem.
    /// </summary>
    public class KnapsackTopDown : IKnapsackSolver
    {
        private static int[] weights = Array.Empty<int>();
        private static int[] values = Array.Empty<int>();
        private static int[,]? memo;
        private static long operationCount;
        private static long recursiveCalls;
        private static long cacheHits;

        public KnapsackResult Solve(int[] itemWeights, int[] itemValues, int capacity)
        {
            if (itemWeights == null || itemValues == null)
                throw new ArgumentNullException("Weights and values arrays cannot be null");

            if (itemWeights.Length != itemValues.Length)
                throw new ArgumentException("Weights and values arrays must have same length");

            if (capacity < 0)
                throw new ArgumentException("Capacity cannot be negative");

            weights = itemWeights;
            values = itemValues;
            int n = weights.Length;

            memo = new int[n + 1, capacity + 1];
            for (int i = 0; i <= n; i++)
                for (int j = 0; j <= capacity; j++)
                    memo[i, j] = -1;

            for (int i = 0; i <= n; i++) memo[i, 0] = 0;
            for (int j = 0; j <= capacity; j++) memo[0, j] = 0;

            operationCount = 0;
            recursiveCalls = 0;
            cacheHits = 0;

            var stopwatch = Stopwatch.StartNew();
            int maxValue = SolveRecursive(n, capacity);
            stopwatch.Stop();

            return new KnapsackResult
            {
                MaxValue = maxValue,
                MemoTable = memo,
                OperationCount = operationCount,
                RecursiveCalls = recursiveCalls,
                CacheHits = cacheHits,
                ExecutionTimeMs = stopwatch.Elapsed.TotalMilliseconds,
                OptimalItems = BacktrackSolution(n, capacity)
            };
        }

        private static int SolveRecursive(int i, int w)
        {
            recursiveCalls++;
            if (memo![i, w] != -1)
            {
                cacheHits++;
                return memo[i, w];
            }

            operationCount++;
            if (i == 0 || w == 0) return 0;

            int weight = weights[i - 1];
            int value = values[i - 1];

            if (weight <= w)
            {
                int include = SolveRecursive(i - 1, w - weight) + value;
                int exclude = SolveRecursive(i - 1, w);
                memo[i, w] = Math.Max(include, exclude);
            }
            else
            {
                memo[i, w] = SolveRecursive(i - 1, w);
            }

            return memo[i, w];
        }

        private static List<int> BacktrackSolution(int n, int capacity)
        {
            var items = new List<int>();
            int i = n, w = capacity;

            while (i > 0 && w > 0)
            {
                if (memo![i, w] != memo[i - 1, w])
                {
                    items.Add(i);
                    w -= weights[i - 1];
                }
                i--;
            }

            items.Reverse();
            return items;
        }
    }
}
