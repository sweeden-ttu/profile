using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace KnapsackAnalysis
{
    /// <summary>
    /// Bottom-up dynamic programming solution for the 0/1 Knapsack problem.
    /// </summary>
    public class KnapsackBottomUp : IKnapsackSolver
    {
        public KnapsackResult Solve(int[] weights, int[] values, int capacity)
        {
            if (weights == null || values == null)
                throw new ArgumentNullException("Weights and values arrays cannot be null");

            if (weights.Length != values.Length)
                throw new ArgumentException("Weights and values arrays must have same length");

            if (capacity < 0)
                throw new ArgumentException("Capacity cannot be negative");

            int n = weights.Length;
            var dp = new int[n + 1, capacity + 1];
            long operationCount = 0;

            var stopwatch = Stopwatch.StartNew();

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= capacity; j++)
                {
                    operationCount++;
                    if (weights[i - 1] <= j)
                    {
                        dp[i, j] = Math.Max(dp[i - 1, j], dp[i - 1, j - weights[i - 1]] + values[i - 1]);
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }

            stopwatch.Stop();

            return new KnapsackResult
            {
                MaxValue = dp[n, capacity],
                DpTable = dp,
                OperationCount = operationCount,
                ExecutionTimeMs = stopwatch.Elapsed.TotalMilliseconds,
                OptimalItems = BacktrackSolution(dp, weights, values, capacity)
            };
        }

        private static List<int> BacktrackSolution(int[,] table, int[] weights, int[] values, int capacity)
        {
            var items = new List<int>();
            int n = weights.Length;
            int i = n, w = capacity;

            while (i > 0 && w > 0)
            {
                if (table[i, w] != table[i - 1, w])
                {
                    items.Add(i);
                    w -= weights[i - 1];
                }
                i--;
            }

            items.Reverse();
            return items;
        }
    }
}
