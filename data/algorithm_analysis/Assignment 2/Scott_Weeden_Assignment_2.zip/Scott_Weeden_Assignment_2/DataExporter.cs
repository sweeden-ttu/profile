using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Text.Json.Serialization;


namespace KnapsackAnalysis
{
    /// <summary>
    /// Data export utilities for performance analysis and visualization
    /// Exports timing and operation data for Python analysis
    /// </summary>
    public static class DataExporter
    {
        public class ExperimentData
        {
            public string TestName { get; set; } = string.Empty;
            public int ItemCount { get; set; }
            public int Capacity { get; set; }
            public string Algorithm { get; set; } = string.Empty;
            public double ExecutionTimeMs { get; set; }
            public long OperationCount { get; set; }
            public long ExpectedOperations { get; set; }
            public double EfficiencyRatio { get; set; }
            public int MaxValue { get; set; }
            public long RecursiveCalls { get; set; } = 0;
            public long CacheHits { get; set; } = 0;
            public double CacheHitRate { get; set; } = 0;
            public int TableUtilization { get; set; } = 0;
            public bool IsCorrect { get; set; }
            public DateTime Timestamp { get; set; } = DateTime.Now;
        }

        private static List<ExperimentData> experimentResults = new List<ExperimentData>();

        /// <summary>
        /// Record experiment data for later export
        /// </summary>
        public static void RecordExperiment(string testName, int n, int W,
            KnapsackResult resultBU,
            KnapsackResult resultTD,
            bool isCorrect)
        {
            long expectedOps = (long)n * W;

            // Record bottom-up data
            experimentResults.Add(new ExperimentData
            {
                TestName = testName,
                ItemCount = n,
                Capacity = W,
                Algorithm = "BottomUp",
                ExecutionTimeMs = resultBU.ExecutionTimeMs,
                OperationCount = resultBU.OperationCount,
                ExpectedOperations = expectedOps,
                EfficiencyRatio = (double)resultBU.OperationCount / expectedOps,
                MaxValue = resultBU.MaxValue,
                TableUtilization = 100, // Bottom-up always fills entire table
                IsCorrect = isCorrect
            });

            // Calculate table utilization for top-down
            int totalEntries = (n + 1) * (W + 1);
            int computedEntries = 0;
            if (resultTD.MemoTable != null)
            {
                for (int i = 0; i <= n; i++)
                {
                    for (int j = 0; j <= W; j++)
                    {
                        if (resultTD.MemoTable[i, j] != -1)
                            computedEntries++;
                    }
                }
            }

            // Record top-down data
            experimentResults.Add(new ExperimentData
            {
                TestName = testName,
                ItemCount = n,
                Capacity = W,
                Algorithm = "TopDown",
                ExecutionTimeMs = resultTD.ExecutionTimeMs,
                OperationCount = resultTD.OperationCount,
                ExpectedOperations = expectedOps,
                EfficiencyRatio = (double)resultTD.OperationCount / expectedOps,
                MaxValue = resultTD.MaxValue,
                RecursiveCalls = resultTD.RecursiveCalls,
                CacheHits = resultTD.CacheHits,
                CacheHitRate = (double)resultTD.CacheHits / resultTD.RecursiveCalls * 100,
                TableUtilization = (int)((double)computedEntries / totalEntries * 100),
                IsCorrect = isCorrect
            });
        }

        /// <summary>
        /// Export all recorded data to CSV file
        /// </summary>
        public static void ExportToCSV(string filename = "knapsack_results.csv")
        {
            try
            {
                using (var writer = new StreamWriter(filename))
                {
                    // Write CSV header
                    writer.WriteLine("TestName,ItemCount,Capacity,Algorithm,ExecutionTimeMs,OperationCount,ExpectedOperations,EfficiencyRatio,MaxValue,RecursiveCalls,CacheHits,CacheHitRate,TableUtilization,IsCorrect,Timestamp");

                    // Write data rows
                    foreach (var result in experimentResults)
                    {
                        writer.WriteLine($"{result.TestName},{result.ItemCount},{result.Capacity},{result.Algorithm}," +
                                       $"{result.ExecutionTimeMs:F6},{result.OperationCount},{result.ExpectedOperations}," +
                                       $"{result.EfficiencyRatio:F6},{result.MaxValue},{result.RecursiveCalls}," +
                                       $"{result.CacheHits},{result.CacheHitRate:F2},{result.TableUtilization}," +
                                       $"{result.IsCorrect},{result.Timestamp:yyyy-MM-dd HH:mm:ss}");
                    }
                }

                Console.WriteLine($"✅ Data exported to {filename} ({experimentResults.Count} records)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to export CSV: {ex.Message}");
            }
        }

        /// <summary>
        /// Export all recorded data to JSON file
        /// </summary>
        public static void ExportToJSON(string filename = "knapsack_results.json")
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true,
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals // 👈 add this line
                };

                string jsonString = JsonSerializer.Serialize(experimentResults, options);
                File.WriteAllText(filename, jsonString);

                Console.WriteLine($"✅ Data exported to {filename} ({experimentResults.Count} records)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to export JSON: {ex.Message}");
            }
        }
        /// <summary>
        /// Generate performance summary report
        /// </summary>
        public static void GenerateSummaryReport(string filename = "performance_summary.txt")
        {
            try
            {
                using (var writer = new StreamWriter(filename))
                {
                    writer.WriteLine("KNAPSACK ALGORITHM PERFORMANCE SUMMARY");
                    writer.WriteLine(new string('=', 50));
                    writer.WriteLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                    writer.WriteLine($"Total experiments: {experimentResults.Count}");
                    writer.WriteLine();

                    // Group by test name
                    var testGroups = new Dictionary<string, List<ExperimentData>>();
                    foreach (var result in experimentResults)
                    {
                        if (!testGroups.ContainsKey(result.TestName))
                            testGroups[result.TestName] = new List<ExperimentData>();
                        testGroups[result.TestName].Add(result);
                    }

                    foreach (var group in testGroups)
                    {
                        writer.WriteLine($"TEST: {group.Key}");
                        writer.WriteLine(new string('-', 30));

                        var buResults = group.Value.FindAll(r => r.Algorithm == "BottomUp");
                        var tdResults = group.Value.FindAll(r => r.Algorithm == "TopDown");

                        if (buResults.Count > 0 && tdResults.Count > 0)
                        {
                            double avgBuTime = buResults.Average(r => r.ExecutionTimeMs);
                            double avgTdTime = tdResults.Average(r => r.ExecutionTimeMs);
                            double avgSpeedup = avgBuTime / avgTdTime;
                            double avgCacheHitRate = tdResults.Average(r => r.CacheHitRate);
                            double avgTableUtil = tdResults.Average(r => r.TableUtilization);

                            writer.WriteLine($"  Average Bottom-up time: {avgBuTime:F4} ms");
                            writer.WriteLine($"  Average Top-down time:  {avgTdTime:F4} ms");
                            writer.WriteLine($"  Average speedup:        {avgSpeedup:F2}x");
                            writer.WriteLine($"  Average cache hit rate: {avgCacheHitRate:F1}%");
                            writer.WriteLine($"  Average table util:     {avgTableUtil:F1}%");
                        }

                        writer.WriteLine();
                    }

                    // Overall statistics
                    writer.WriteLine("OVERALL STATISTICS");
                    writer.WriteLine(new string('-', 30));

                    var allBu = experimentResults.FindAll(r => r.Algorithm == "BottomUp");
                    var allTd = experimentResults.FindAll(r => r.Algorithm == "TopDown");

                    if (allBu.Count > 0 && allTd.Count > 0)
                    {
                        writer.WriteLine($"Total Bottom-up experiments: {allBu.Count}");
                        writer.WriteLine($"Total Top-down experiments:  {allTd.Count}");
                        writer.WriteLine($"Average Bottom-up efficiency: {allBu.Average(r => r.EfficiencyRatio):F3}");
                        writer.WriteLine($"Average Top-down efficiency:  {allTd.Average(r => r.EfficiencyRatio):F3}");
                        writer.WriteLine($"Overall cache hit rate:       {allTd.Average(r => r.CacheHitRate):F1}%");
                        writer.WriteLine($"Overall table utilization:    {allTd.Average(r => r.TableUtilization):F1}%");
                    }
                }

                Console.WriteLine($"✅ Summary report generated: {filename}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to generate summary: {ex.Message}");
            }
        }

        /// <summary>
        /// Clear all recorded experiment data
        /// </summary>
        public static void ClearData()
        {
            experimentResults.Clear();
            Console.WriteLine("Experiment data cleared.");
        }

        /// <summary>
        /// Get current experiment count
        /// </summary>
        public static int GetExperimentCount()
        {
            return experimentResults.Count;
        }
    }
}