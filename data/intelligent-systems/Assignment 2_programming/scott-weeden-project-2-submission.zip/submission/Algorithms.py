import util

class DFS(object):
    def depthFirstSearch(self, problem):
        """
        Search the deepest nodes in the search tree first
        [2nd Edition: p 75, 3rd Edition: p 87]
        Your search algorithm needs to return a list of actions that reaches
        the goal.  Make sure to implement a graph search algorithm
        [2nd Edition: Fig. 3.18, 3rd Edition: Fig 3.7].

        To get started, you might want to try some of these simple commands to
        understand the search problem that is being passed in:

        print "Start:", problem.getStartState()
        print "Is the start a goal?", problem.isGoalState(problem.getStartState())
        print "Start's successors:", problem.getSuccessors(problem.getStartState())
        """
        "*** TTU CS 5368 Fall 2025 YOUR CODE HERE ***"
        # Initialize the fringe (stack for DFS) with the start state
        # Each element is a tuple: (state, actions_to_reach_state)
        fringe = util.Stack()
        fringe.push((problem.getStartState(), []))

        # Keep track of visited states to avoid cycles (graph search)
        visited = set()

        while not fringe.isEmpty():
            # Pop the deepest node from the stack
            state, actions = fringe.pop()

            # Skip if already visited
            if state in visited:
                continue

            # Mark as visited
            visited.add(state)

            # Check if we reached the goal
            if problem.isGoalState(state):
                return actions

            # Expand the node by adding successors to the fringe
            for successor, action, stepCost in problem.getSuccessors(state):
                if successor not in visited:
                    # Push successor with the path to reach it
                    fringe.push((successor, actions + [action]))

        # No solution found
        return []

class BFS(object):
    def breadthFirstSearch(self, problem):
        "*** TTU CS 5368 Fall 2025 YOUR CODE HERE ***"
        # Queue drives BFS to explore shallower nodes first
        fringe = util.Queue()
        start_state = problem.getStartState()
        fringe.push((start_state, []))

        # Track visited states when they enter the queue to avoid re-enqueueing
        visited = {start_state}

        while not fringe.isEmpty():
            state, actions = fringe.pop()

            # If the goal is reached, the current action list is optimal
            if problem.isGoalState(state):
                return actions

            for successor, action, step_cost in problem.getSuccessors(state):
                if successor not in visited:
                    visited.add(successor)
                    fringe.push((successor, actions + [action]))

        # No solution found
        return []

class UCS(object):
    def uniformCostSearch(self, problem):
        "*** TTU CS 5368 Fall 2025 YOUR CODE HERE ***"
        fringe = util.PriorityQueue()
        start_state = problem.getStartState()
        fringe.push((start_state, [], 0), 0)

        # Track the lowest cost discovered for each state
        best_cost = {start_state: 0}

        while not fringe.isEmpty():
            state, actions, cost_so_far = fringe.pop()

            # Skip if we've already found a cheaper path to this state
            if cost_so_far > best_cost.get(state, float('inf')):
                continue

            if problem.isGoalState(state):
                return actions

            for successor, action, step_cost in problem.getSuccessors(state):
                new_cost = cost_so_far + step_cost
                if new_cost < best_cost.get(successor, float('inf')):
                    best_cost[successor] = new_cost
                    fringe.push((successor, actions + [action], new_cost), new_cost)

        return []
        
class aSearch (object):
    def nullHeuristic( state, problem=None):
        """
        A heuristic function estimates the cost from the current state to the nearest goal in the provided SearchProblem.  This heuristic is trivial.
        """
        return 0
    def aStarSearch(self,problem, heuristic=nullHeuristic):
        "Search the node that has the lowest combined cost and heuristic first."
        "*** TTU CS 5368 Fall 2025 YOUR CODE HERE ***"
        fringe = util.PriorityQueue()
        start_state = problem.getStartState()
        start_cost = heuristic(start_state, problem)
        fringe.push((start_state, [], 0), start_cost)

        best_cost = {start_state: 0}

        while not fringe.isEmpty():
            state, actions, cost_so_far = fringe.pop()

            if cost_so_far > best_cost.get(state, float('inf')):
                continue

            if problem.isGoalState(state):
                return actions

            for successor, action, step_cost in problem.getSuccessors(state):
                new_cost = cost_so_far + step_cost
                if new_cost < best_cost.get(successor, float('inf')):
                    best_cost[successor] = new_cost
                    priority = new_cost + heuristic(successor, problem)
                    fringe.push((successor, actions + [action], new_cost), priority)

        return []
