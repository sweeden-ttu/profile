# LaTeX submission bundle (NIST Quiz #3)

## Build the course report PDF (`main.tex`)

Requirements: TeX distribution with **latexmk**, **newtx** (`newtxtext`, `newtxmath`), **natbib**, **hyperref**, **fancyhdr**, **booktabs**.

```bash
cd src
latexmk -pdf -interaction=nonstopmode main.tex
```

The first run may call **bibtex**; `latexmk` runs the full cycle. Output: `src/main.pdf`.

If `src/main.pdf` is bundled, it was rebuilt when the archive was created; you can submit it directly or rebuild from sources.

Paths in this bundle mirror the repository: `experiment.tex` inputs `../output/results/nist_rubric_table.tex`.
Optional figures belong in `output/diagrams/` (see `output/diagrams/README.txt`).

## Optional: IEEE legacy layout

```bash
cd src
latexmk -pdf -interaction=nonstopmode ieee_journal.tex
```

Requires the **IEEEtran** class (e.g. `texlive-publishers`).

## Regenerate the rubric table fragment

If you edit `output/results/nist_quiz_scores.json`:

```bash
python scripts/emit_nist_rubric_table.py
```

(Requires the full repo with `scripts/`; this zip focuses on compiling the PDF from frozen outputs.)
