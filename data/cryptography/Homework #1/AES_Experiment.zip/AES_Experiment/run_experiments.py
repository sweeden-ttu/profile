#!/usr/bin/env python3
"""
Combined Experiment Runner
CS 6343 - Spring 2026

Runs all AES cryptanalysis experiments and generates summary report.
"""

import json
import subprocess
from pathlib import Path
from datetime import datetime


WORK_DIR = Path("/Users/sweeden/crypto_proj/AES_Experiment")


def run_command(cmd, description):
    """Run a command and print status"""
    print(f"\n{'=' * 60}")
    print(f"Running: {description}")
    print(f"{'=' * 60}")

    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

    if result.stdout:
        print(result.stdout)
    if result.returncode != 0 and result.stderr:
        print(f"Error: {result.stderr}")

    return result.returncode


def generate_summary_report():
    """Generate final summary report from all experiment results"""

    report = []
    report.append("=" * 70)
    report.append("AES CRYPTANALYSIS EXPERIMENT RESULTS")
    report.append("CS 6343 - Spring 2026")
    report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 70)

    result_files = [
        "results_part_a.json",
        "results_part_b.json",
        "results_part_c.json",
        "results_part_d_standard.json",
        "results_part_d_no_shiftrows.json",
        "results_part_d_modified.json",
    ]

    for rf in result_files:
        fp = WORK_DIR / rf
        if fp.exists():
            with open(fp) as f:
                data = json.load(f)

            report.append(f"\n### {rf} ###")

            if "rounds" in data:
                for r in data["rounds"]:
                    if r["stage"] == "AddRoundKey":
                        report.append(
                            f"Round {r['round']:2d}: "
                            f"Byte Hamming: {r['byte_hamming']:2d}/16 ({r['byte_percent']:5.1f}%), "
                            f"Bit Hamming: {r['bit_hamming']:3d}/128 ({r['bit_percent']:5.1f}%)"
                        )

    report.append("\n" + "=" * 70)
    report.append("ANALYSIS SUMMARY")
    report.append("=" * 70)
    report.append("""
Expected vs Observed Patterns:

Part A (Standard AES):
- Round 0: ~1 bit (only AddRoundKey XOR)
- Round 1-2: 12-25% bits (SubBytes begins diffusion)
- Round 5+: ~50% bits (full avalanche achieved)

Part B (No ShiftRows):
- Should show significantly lower diffusion
- Maximum ~25% even at final rounds
- Confirms ShiftRows provides critical cross-column diffusion

Part C (Modified MixColumns):
- Slower diffusion than standard
- Should show ~35-40% at round 10
- Confirms MixColumns strength impacts diffusion

Part D (Key Flip):
- Similar patterns to plaintext flip
- Confirms symmetry of AddRoundKey operation
""")

    report_text = "\n".join(report)

    with open(WORK_DIR / "experiment_summary.txt", "w") as f:
        f.write(report_text)

    print(report_text)
    print(f"\nSummary saved to: {WORK_DIR / 'experiment_summary.txt'}")


def main():
    """Run all experiments"""
    print("=" * 70)
    print("AES CRYPTANALYSIS - COMPLETE EXPERIMENT SUITE")
    print("=" * 70)

    print("\n[1/3] Running AES cryptanalysis experiments...")
    result = subprocess.run(
        ["python3", str(WORK_DIR / "aes_cryptanalysis.py")],
        capture_output=True,
        text=True,
    )
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(f"Errors: {result.stderr}")

    print("\n[2/3] AES modes experiment available at:")
    print(f"  {WORK_DIR / 'aes_modes_experiment.py'}")
    print("  (Run manually with actual image file)")

    print("\n[3/3] Generating summary report...")
    generate_summary_report()

    print("\n" + "=" * 70)
    print("EXPERIMENTS COMPLETE")
    print("=" * 70)
    print(f"\nOutput files in: {WORK_DIR}")
    print("  - results_part_a.json (Standard AES)")
    print("  - results_part_b.json (No ShiftRows)")
    print("  - results_part_c.json (Modified MixColumns)")
    print("  - results_part_d_*.json (Key flip experiments)")
    print("  - experiment_summary.txt")


if __name__ == "__main__":
    main()
