#!/usr/bin/env python3
"""
AES Mode of Operation Comparison Experiment
CS 6343 - Spring 2026

This script compares ECB and CBC modes of operation for AES encryption.
It demonstrates how ECB preserves patterns while CBC provides semantic security.
"""

import os
import subprocess
import shutil
from pathlib import Path


def generate_random_key_iv():
    """Generate random 16-byte key and IV using OpenSSL"""
    key = subprocess.run(
        ["openssl", "rand", "hex", "16"], capture_output=True, text=True
    ).stdout.strip()

    iv = subprocess.run(
        ["openssl", "rand", "hex", "16"], capture_output=True, text=True
    ).stdout.strip()

    return key, iv


def encrypt_file_openssl(
    input_file: str, output_file: str, key: str, iv: str = None, mode: str = "ecb"
) -> bool:
    """
    Encrypt file using OpenSSL AES

    Args:
        input_file: Path to input file
        output_file: Path to output file
        key: 32-character hex key (16 bytes)
        iv: 32-character hex IV (16 bytes) - required for CBC
        mode: 'ecb' or 'cbc'

    Returns:
        True if successful
    """
    cmd = ["openssl", "enc", "-aes-" + mode, "-K", key]

    if mode == "cbc" and iv:
        cmd.extend(["-iv", iv])

    cmd.extend(["-in", input_file, "-out", output_file])

    result = subprocess.run(cmd, capture_output=True)
    return result.returncode == 0


def copy_bmp_header(
    original_file: str, encrypted_file: str, output_file: str, header_size: int = 54
):
    """
    Copy BMP header from original to encrypted file

    Args:
        original_file: Original unencrypted BMP
        encrypted_file: Encrypted file without proper header
        output_file: Output file with original header
        header_size: BMP header size (54 bytes)
    """
    with open(original_file, "rb") as orig:
        header = orig.read(header_size)

    with open(encrypted_file, "rb") as enc:
        encrypted_data = enc.read()

    with open(output_file, "wb") as out:
        out.write(header)
        out.write(encrypted_data)


def run_mode_comparisonExperiment(image_path: str):
    """
    Main experiment comparing ECB and CBC modes

    Args:
        image_path: Path to Secret.bmp or similar image
    """
    work_dir = Path("/Users/sweeden/crypto_proj/AES_Experiment")

    key, iv = generate_random_key_iv()
    print(f"Generated key: {key}")
    print(f"Generated IV: {iv}")

    base_name = Path(image_path).stem
    ext = Path(image_path).suffix

    ecb_encrypted = work_dir / f"{base_name}_ecb.enc"
    cbc_encrypted = work_dir / f"{base_name}_cbc.enc"

    ecb_fixed = work_dir / f"{base_name}_ecb_fixed{ext}"
    cbc_fixed = work_dir / f"{base_name}_cbc_fixed{ext}"

    print(f"\n[1] Encrypting with ECB mode...")
    encrypt_file_openssl(image_path, str(ecb_encrypted), key, mode="ecb")
    print(f"  ECB encrypted: {ecb_encrypted}")

    print(f"\n[2] Encrypting with CBC mode...")
    encrypt_file_openssl(image_path, str(cbc_encrypted), key, iv, mode="cbc")
    print(f"  CBC encrypted: {cbc_encrypted}")

    print(f"\n[3] Fixing BMP headers...")
    copy_bmp_header(image_path, str(ecb_encrypted), str(ecb_fixed))
    copy_bmp_header(image_path, str(cbc_encrypted), str(cbc_fixed))
    print(f"  ECB fixed: {ecb_fixed}")
    print(f"  CBC fixed: {cbc_fixed}")

    results = {
        "key": key,
        "iv": iv,
        "original_image": str(image_path),
        "ecb_encrypted": str(ecb_encrypted),
        "cbc_encrypted": str(cbc_encrypted),
        "ecb_fixed": str(ecb_fixed),
        "cbc_fixed": str(cbc_fixed),
    }

    import json

    with open(work_dir / "mode_comparison_results.json", "w") as f:
        json.dump(results, f, indent=2)

    print("\n" + "=" * 60)
    print("OBSERVATIONS:")
    print("=" * 60)
    print("""
Before header fix:
- Both ECB and CBC encrypted files will be unviewable
- The BMP header is corrupted

After copying original header:
- ECB: Should show visible patterns/ghost images
- CBC: Should appear as random noise (proper encryption)

EXPLANATION:
- ECB encrypts each 16-byte block independently
- Identical plaintext blocks produce identical ciphertext
- Repeated patterns in image (e.g., solid areas) remain visible
- CBC XORs previous ciphertext with plaintext, providing semantic security
""")

    return results


def analyze_encrypted_bytes(file_path: str, sample_size: int = 32):
    """Analyze first few bytes of encrypted file"""
    with open(file_path, "rb") as f:
        data = f.read(sample_size)

    print(f"\nFirst {sample_size} bytes of {file_path}:")
    print("Hex:", data.hex())

    unique_blocks = set()
    for i in range(0, len(data), 16):
        block = data[i : i + 16]
        if len(block) == 16:
            unique_blocks.add(block)

    print(f"Unique 16-byte blocks in first {sample_size} bytes: {len(unique_blocks)}")


def main():
    """Main entry point"""
    work_dir = Path("/Users/sweeden/crypto_proj/AES_Experiment")

    image_path = work_dir / "Secret.bmp"

    if not image_path.exists():
        print(f"Error: {image_path} not found!")
        print("Please place Secret.bmp in the AES_Experiment directory")
        return

    print("=" * 60)
    print("AES Mode Comparison Experiment")
    print("=" * 60)

    run_mode_comparisonExperiment(str(image_path))

    print("\n[4] Analyzing byte patterns...")

    for mode in ["ecb", "cbc"]:
        enc_file = work_dir / f"Secret_{mode}.enc"
        if enc_file.exists():
            analyze_encrypted_bytes(str(enc_file))


if __name__ == "__main__":
    main()
