"""
AES Cryptanalysis Experiments
CS 6343 - Spring 2026

This module implements AES with controllable components for studying:
- Avalanche effect across rounds
- Impact of ShiftRows
- Impact of MixColumns modifications
- Key vs plaintext bit flip experiments
"""

import numpy as np
from typing import Tuple, List, Dict
import json


SBOX = [
    0x63,
    0x7C,
    0x77,
    0x7B,
    0xF2,
    0x6B,
    0x6F,
    0xC5,
    0x30,
    0x01,
    0x67,
    0x2B,
    0xFE,
    0xD7,
    0xAB,
    0x76,
    0xCA,
    0x82,
    0xC9,
    0x7D,
    0xFA,
    0x59,
    0x47,
    0xF0,
    0xAD,
    0xD4,
    0xA2,
    0xAF,
    0x9C,
    0xA4,
    0x72,
    0xC0,
    0xB7,
    0xFD,
    0x93,
    0x26,
    0x36,
    0x3F,
    0xF7,
    0xCC,
    0x34,
    0xA5,
    0xE5,
    0xF1,
    0x71,
    0xD8,
    0x31,
    0x15,
    0x04,
    0xC7,
    0x23,
    0xC3,
    0x18,
    0x96,
    0x05,
    0x9A,
    0x07,
    0x12,
    0x80,
    0xE2,
    0xEB,
    0x27,
    0xB2,
    0x75,
    0x09,
    0x83,
    0x2C,
    0x1A,
    0x1B,
    0x6E,
    0x5A,
    0xA0,
    0x52,
    0x3B,
    0xD6,
    0xB3,
    0x29,
    0xE3,
    0x2F,
    0x84,
    0x53,
    0xD1,
    0x00,
    0xED,
    0x20,
    0xFC,
    0xB1,
    0x5B,
    0x6A,
    0xCB,
    0xBE,
    0x39,
    0x4A,
    0x4C,
    0x58,
    0xCF,
    0xD0,
    0xEF,
    0xAA,
    0xFB,
    0x43,
    0x4D,
    0x33,
    0x85,
    0x45,
    0xF9,
    0x02,
    0x7F,
    0x50,
    0x3C,
    0x9F,
    0xA8,
    0x51,
    0xA3,
    0x40,
    0x8F,
    0x92,
    0x9D,
    0x38,
    0xF5,
    0xBC,
    0xB6,
    0xDA,
    0x21,
    0x10,
    0xFF,
    0xF3,
    0xD2,
    0xCD,
    0x0C,
    0x13,
    0xEC,
    0x5F,
    0x97,
    0x44,
    0x17,
    0xC4,
    0xA7,
    0x7E,
    0x3D,
    0x64,
    0x5D,
    0x19,
    0x73,
    0x60,
    0x81,
    0x4F,
    0xDC,
    0x22,
    0x2A,
    0x90,
    0x88,
    0x46,
    0xEE,
    0xB8,
    0x14,
    0xDE,
    0x5E,
    0x0B,
    0xDB,
    0xE0,
    0x32,
    0x3A,
    0x0A,
    0x49,
    0x06,
    0x24,
    0x5C,
    0xC2,
    0xD3,
    0xAC,
    0x62,
    0x91,
    0x95,
    0xE4,
    0x79,
    0xE7,
    0xC8,
    0x37,
    0x6D,
    0x8D,
    0xD5,
    0x4E,
    0xA9,
    0x6C,
    0x56,
    0xF4,
    0xEA,
    0x65,
    0x7A,
    0xAE,
    0x08,
    0xBA,
    0x78,
    0x25,
    0x2E,
    0x1C,
    0xA6,
    0xB4,
    0xC6,
    0xE8,
    0xDD,
    0x74,
    0x1F,
    0x4B,
    0xBD,
    0x8B,
    0x8A,
    0x70,
    0x3E,
    0xB5,
    0x66,
    0x48,
    0x03,
    0xF6,
    0x0E,
    0x61,
    0x35,
    0x57,
    0xB9,
    0x86,
    0xC1,
    0x1D,
    0x9E,
    0xE1,
    0xF8,
    0x98,
    0x11,
    0x69,
    0xD9,
    0x8E,
    0x94,
    0x9B,
    0x1E,
    0x87,
    0xE9,
    0xCE,
    0x55,
    0x28,
    0xDF,
    0x8C,
    0xA1,
    0x89,
    0x0D,
    0xBF,
    0xE6,
    0x42,
    0x68,
    0x41,
    0x99,
    0x2D,
    0x0F,
    0xB0,
    0x54,
    0xBB,
    0x16,
]

INV_SBOX = [
    0x52,
    0x09,
    0x6A,
    0xD5,
    0x30,
    0x36,
    0xA5,
    0x38,
    0xBF,
    0x40,
    0xA3,
    0x9E,
    0x81,
    0xF3,
    0xD7,
    0xFB,
    0x7C,
    0xE3,
    0x39,
    0x82,
    0x9B,
    0x2F,
    0xFF,
    0x87,
    0x34,
    0x8E,
    0x43,
    0x44,
    0xC4,
    0xDE,
    0xE9,
    0xCB,
    0x54,
    0x7B,
    0x94,
    0x32,
    0xA6,
    0xC2,
    0x23,
    0x3D,
    0xEE,
    0x4C,
    0x95,
    0x0B,
    0x42,
    0xFA,
    0xC3,
    0x4E,
    0x08,
    0x2E,
    0xA1,
    0x66,
    0x28,
    0xD9,
    0x24,
    0xB2,
    0x76,
    0x5B,
    0xA2,
    0x49,
    0x6D,
    0x8B,
    0xD1,
    0x25,
    0x72,
    0xF8,
    0xF6,
    0x64,
    0x86,
    0x68,
    0x98,
    0x16,
    0xD4,
    0xA4,
    0x5C,
    0xCC,
    0x5D,
    0x65,
    0xB6,
    0x92,
    0x6C,
    0x70,
    0x48,
    0x50,
    0xFD,
    0xED,
    0xB9,
    0xDA,
    0x5E,
    0x15,
    0x46,
    0x57,
    0xA7,
    0x8D,
    0x9D,
    0x84,
    0x90,
    0xD8,
    0xAB,
    0x00,
    0x8C,
    0xBC,
    0xD3,
    0x0A,
    0xF7,
    0xE4,
    0x58,
    0x05,
    0xB8,
    0xB3,
    0x45,
    0x06,
    0xD0,
    0x2C,
    0x1E,
    0x8F,
    0xCA,
    0x3F,
    0x0F,
    0x02,
    0xC1,
    0xAF,
    0xBD,
    0x03,
    0x01,
    0x13,
    0x8A,
    0x6B,
    0x3A,
    0x91,
    0x11,
    0x41,
    0x4F,
    0x67,
    0xDC,
    0xEA,
    0x97,
    0xF2,
    0xCF,
    0xCE,
    0xF0,
    0xB4,
    0xE6,
    0x73,
    0x96,
    0xAC,
    0x74,
    0x22,
    0xE7,
    0xAD,
    0x35,
    0x85,
    0xE2,
    0xF9,
    0x37,
    0xE8,
    0x1C,
    0x75,
    0xDF,
    0x6E,
    0x47,
    0xF1,
    0x1A,
    0x71,
    0x1D,
    0x29,
    0xC5,
    0x89,
    0x6F,
    0xB7,
    0x62,
    0x0E,
    0xAA,
    0x18,
    0xBE,
    0x1B,
    0xFC,
    0x56,
    0x3E,
    0x4B,
    0xC6,
    0xD2,
    0x79,
    0x20,
    0x9A,
    0xDB,
    0xC0,
    0xFE,
    0x78,
    0xCD,
    0x5A,
    0xF4,
    0x1F,
    0xDD,
    0xA8,
    0x33,
    0x88,
    0x07,
    0xC7,
    0x31,
    0xB1,
    0x12,
    0x10,
    0x59,
    0x27,
    0x80,
    0xEC,
    0x5F,
    0x60,
    0x51,
    0x7F,
    0xA9,
    0x19,
    0xB5,
    0x4A,
    0x0D,
    0x2D,
    0xE5,
    0x7A,
    0x9F,
    0x93,
    0xC9,
    0x9C,
    0xEF,
    0xA0,
    0xE0,
    0x3B,
    0x4D,
    0xAE,
    0x2A,
    0xF5,
    0xB0,
    0xC8,
    0xEB,
    0xBB,
    0x3C,
    0x83,
    0x53,
    0x99,
    0x61,
    0x17,
    0x2B,
    0x04,
    0x7E,
    0xBA,
    0x77,
    0xD6,
    0x26,
    0xE1,
    0x69,
    0x14,
    0x63,
    0x55,
    0x21,
    0x0C,
    0x7D,
]

RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]

STANDARD_MIXCOLUMNS = [
    [0x02, 0x03, 0x01, 0x01],
    [0x01, 0x02, 0x03, 0x01],
    [0x01, 0x01, 0x02, 0x03],
    [0x03, 0x01, 0x01, 0x02],
]

MODIFIED_MIXCOLUMNS = [
    [0x01, 0x01, 0x00, 0x00],
    [0x00, 0x01, 0x01, 0x00],
    [0x00, 0x00, 0x01, 0x01],
    [0x00, 0x00, 0x00, 0x01],
]


def xtime(a: int) -> int:
    """GF(2^8) multiplication by x (i.e., mul by 2)"""
    return ((a << 1) & 0xFF) ^ (0x1B if (a & 0x80) else 0x00)


def gf_mul(a: int, b: int) -> int:
    """GF(2^8) multiplication using xtime"""
    result = 0
    for _ in range(8):
        if b & 1:
            result ^= a
        hi_bit = a & 0x80
        a = (a << 1) & 0xFF
        if hi_bit:
            a ^= 0x1B
        b >>= 1
    return result


def hamming_distance_bytes(b1: bytes, b2: bytes) -> int:
    """Calculate byte Hamming distance (number of differing bytes)"""
    return sum(x != y for x, y in zip(b1, b2))


def hamming_distance_bits(b1: bytes, b2: bytes) -> int:
    """Calculate bit Hamming distance (number of differing bits)"""
    diff = bytes(x ^ y for x, y in zip(b1, b2))
    return sum(bin(byte).count("1") for byte in diff)


class AES:
    """AES-128 implementation with configurable components"""

    def __init__(
        self,
        key: bytes,
        enable_shiftrows: bool = True,
        mixcolumns_matrix: List[List[int]] = None,
    ):
        self.key = key
        self.enable_shiftrows = enable_shiftrows
        self.mixcolumns = mixcolumns_matrix or STANDARD_MIXCOLUMNS
        self.round_keys = self._key_expansion(key)

    def _key_expansion(self, key: bytes) -> List[bytes]:
        """Key expansion for AES-128 (10 rounds)"""
        Nk = 4
        Nr = 10
        Nb = 4

        w = []
        for i in range(Nk):
            w.append(key[i * 4 : (i + 1) * 4])

        for i in range(Nk, Nb * (Nr + 1)):
            temp = w[i - 1]
            if i % Nk == 0:
                temp = bytes(SBOX[b] for b in self._rot_word(temp))
                temp = bytes(a ^ RCON[i // Nk - 1] for a, b in zip(temp, w[i - Nk]))
            elif Nk > 6 and i % Nk == 3:
                temp = bytes(SBOX[b] for b in temp)
            w.append(bytes(a ^ b for a, b in zip(w[i - Nk], temp)))

        round_keys = []
        for i in range(0, Nb * (Nr + 1), Nb):
            round_key = w[i] + w[i + 1] + w[i + 2] + w[i + 3]
            round_keys.append(round_key)

        return round_keys

    def _rot_word(self, word: bytes) -> bytes:
        """Rotate word: [b0,b1,b2,b3] -> [b1,b2,b3,b0]"""
        return word[1:] + word[:1]

    def _sub_bytes(self, state: bytes) -> bytes:
        """SubBytes: S-box substitution"""
        return bytes(SBOX[b] for b in state)

    def _inv_sub_bytes(self, state: bytes) -> bytes:
        """Inverse SubBytes"""
        return bytes(INV_SBOX[b] for b in state)

    def _shift_rows(self, state: bytes) -> bytes:
        """ShiftRows: cyclically shift rows left in AES state (column-major order)

        State is 4x4 matrix in column-major order:
        s[0],s[1],s[2],s[3] = col 0 (rows 0-3)
        s[4],s[5],s[6],s[7] = col 1
        s[8],s[9],s[10],s[11] = col 2
        s[12],s[13],s[14],s[15] = col 3

        Shift:
        - Row 0: no shift
        - Row 1: shift left 1
        - Row 2: shift left 2
        - Row 3: shift left 3
        """
        s = list(state)
        new_state = bytearray(16)

        new_state[0] = s[0]
        new_state[4] = s[4]
        new_state[8] = s[8]
        new_state[12] = s[12]

        new_state[1] = s[5]
        new_state[5] = s[9]
        new_state[9] = s[13]
        new_state[13] = s[1]

        new_state[2] = s[10]
        new_state[6] = s[14]
        new_state[10] = s[2]
        new_state[14] = s[6]

        new_state[3] = s[15]
        new_state[7] = s[3]
        new_state[11] = s[7]
        new_state[15] = s[11]

        return bytes(new_state)

    def _inv_shift_rows(self, state: bytes) -> bytes:
        """Inverse ShiftRows"""
        s = list(state)
        new_state = bytearray(16)

        new_state[0] = s[0]
        new_state[1] = s[13]
        new_state[2] = s[10]
        new_state[3] = s[7]

        new_state[4] = s[4]
        new_state[5] = s[1]
        new_state[6] = s[14]
        new_state[7] = s[11]

        new_state[8] = s[8]
        new_state[9] = s[5]
        new_state[10] = s[2]
        new_state[11] = s[15]

        new_state[12] = s[12]
        new_state[13] = s[9]
        new_state[14] = s[6]
        new_state[15] = s[3]

        return bytes(new_state)

    def _mix_columns(self, state: bytes) -> bytes:
        """MixColumns: column mixing operation"""
        result = bytearray(16)

        for col in range(4):
            for row in range(4):
                total = 0
                for k in range(4):
                    total ^= gf_mul(self.mixcolumns[row][k], state[col * 4 + k])
                result[col * 4 + row] = total

        return bytes(result)

    def _add_round_key(self, state: bytes, round_key: bytes) -> bytes:
        """AddRoundKey: XOR state with round key"""
        return bytes(a ^ b for a, b in zip(state, round_key))

    def encrypt(
        self, plaintext: bytes, record_states: bool = False
    ) -> Tuple[bytes, List[Dict]]:
        """
        Encrypt plaintext using AES
        Returns: (ciphertext, list of intermediate states)
        """
        if len(plaintext) != 16:
            raise ValueError("Plaintext must be 16 bytes")

        states_log = []
        state = plaintext

        state = self._add_round_key(state, self.round_keys[0])
        if record_states:
            states_log.append(
                {"round": 0, "stage": "AddRoundKey", "state": state.hex()}
            )

        for round_num in range(1, 10):
            state = self._sub_bytes(state)
            if record_states:
                states_log.append(
                    {"round": round_num, "stage": "SubBytes", "state": state.hex()}
                )

            state = self._shift_rows(state) if self.enable_shiftrows else state
            if record_states:
                states_log.append(
                    {"round": round_num, "stage": "ShiftRows", "state": state.hex()}
                )

            state = self._mix_columns(state)
            if record_states:
                states_log.append(
                    {"round": round_num, "stage": "MixColumns", "state": state.hex()}
                )

            state = self._add_round_key(state, self.round_keys[round_num])
            if record_states:
                states_log.append(
                    {"round": round_num, "stage": "AddRoundKey", "state": state.hex()}
                )

        state = self._sub_bytes(state)
        if record_states:
            states_log.append({"round": 10, "stage": "SubBytes", "state": state.hex()})

        state = self._shift_rows(state) if self.enable_shiftrows else state
        if record_states:
            states_log.append({"round": 10, "stage": "ShiftRows", "state": state.hex()})

        state = self._add_round_key(state, self.round_keys[10])
        if record_states:
            states_log.append(
                {"round": 10, "stage": "AddRoundKey", "state": state.hex()}
            )

        return state, states_log


def run_avalanche_experiment(
    key: bytes,
    plaintext: bytes,
    plaintext_prime: bytes,
    enable_shiftrows: bool = True,
    mixcolumns_matrix: List[List[int]] = None,
) -> Dict:
    """
    Run avalanche experiment comparing two plaintexts
    """
    aes = AES(key, enable_shiftrows, mixcolumns_matrix)

    _, states1 = aes.encrypt(plaintext, record_states=True)
    _, states2 = aes.encrypt(plaintext_prime, record_states=True)

    results = {
        "part": "A"
        if enable_shiftrows and mixcolumns_matrix is None
        else "B"
        if not enable_shiftrows
        else "C",
        "rounds": [],
    }

    round_states = {}
    for s in states1:
        r = s["round"]
        if r not in round_states:
            round_states[r] = {
                "SubBytes": None,
                "ShiftRows": None,
                "MixColumns": None,
                "AddRoundKey": None,
            }
        round_states[r][s["stage"]] = s["state"]

    for s in states2:
        r = s["round"]
        if r in round_states:
            round_states[r][f"{s['stage']}_prime"] = s["state"]

    for round_num in range(11):
        if round_num in round_states:
            for stage in ["AddRoundKey", "SubBytes", "ShiftRows", "MixColumns"]:
                key1 = stage
                key2 = f"{stage}_prime"
                if key1 in round_states[round_num] and key2 in round_states[round_num]:
                    state1 = bytes.fromhex(round_states[round_num][key1])
                    state2 = bytes.fromhex(round_states[round_num][key2])

                    byte_dist = hamming_distance_bytes(state1, state2)
                    bit_dist = hamming_distance_bits(state1, state2)

                    results["rounds"].append(
                        {
                            "round": round_num,
                            "stage": stage,
                            "byte_hamming": byte_dist,
                            "bit_hamming": bit_dist,
                            "byte_percent": byte_dist / 16 * 100,
                            "bit_percent": bit_dist / 128 * 100,
                        }
                    )

    return results


def run_key_flip_experiment(
    key: bytes,
    key_prime: bytes,
    plaintext: bytes,
    enable_shiftrows: bool = True,
    mixcolumns_matrix: List[List[int]] = None,
) -> Dict:
    """
    Run key flip experiment (Part D)
    """
    return run_avalanche_experiment(
        key, plaintext, plaintext, enable_shiftrows, mixcolumns_matrix
    )


def save_results(results: Dict, filename: str):
    """Save experiment results to JSON"""
    with open(filename, "w") as f:
        json.dump(results, f, indent=2)


def main():
    """Main experiment runner"""
    key = bytes(16)
    plaintext = bytes(16)
    plaintext_prime = bytes([1] + [0] * 15)

    print("=" * 60)
    print("AES Cryptanalysis Experiments - CS 6343")
    print("=" * 60)

    print("\n### Part A: Standard AES Avalanche ###")
    results_a = run_avalanche_experiment(
        key, plaintext, plaintext_prime, enable_shiftrows=True, mixcolumns_matrix=None
    )
    save_results(
        results_a, "/Users/sweeden/crypto_proj/AES_Experiment/results_part_a.json"
    )
    print("Saved to results_part_a.json")

    print("\n### Part B: No ShiftRows ###")
    results_b = run_avalanche_experiment(
        key, plaintext, plaintext_prime, enable_shiftrows=False, mixcolumns_matrix=None
    )
    save_results(
        results_b, "/Users/sweeden/crypto_proj/AES_Experiment/results_part_b.json"
    )
    print("Saved to results_part_b.json")

    print("\n### Part C: Modified MixColumns ###")
    results_c = run_avalanche_experiment(
        key,
        plaintext,
        plaintext_prime,
        enable_shiftrows=True,
        mixcolumns_matrix=MODIFIED_MIXCOLUMNS,
    )
    save_results(
        results_c, "/Users/sweeden/crypto_proj/AES_Experiment/results_part_c.json"
    )
    print("Saved to results_part_c.json")

    print("\n### Part D: Key Flip - Standard AES ###")
    key_prime = bytes([1] + [0] * 15)
    results_d_std = run_key_flip_experiment(
        key, key_prime, plaintext, enable_shiftrows=True, mixcolumns_matrix=None
    )
    save_results(
        results_d_std,
        "/Users/sweeden/crypto_proj/AES_Experiment/results_part_d_standard.json",
    )
    print("Saved to results_part_d_standard.json")

    print("\n### Part D: Key Flip - No ShiftRows ###")
    results_d_no_sr = run_key_flip_experiment(
        key, key_prime, plaintext, enable_shiftrows=False, mixcolumns_matrix=None
    )
    save_results(
        results_d_no_sr,
        "/Users/sweeden/crypto_proj/AES_Experiment/results_part_d_no_shiftrows.json",
    )
    print("Saved to results_part_d_no_shiftrows.json")

    print("\n### Part D: Key Flip - Modified MixColumns ###")
    results_d_mod = run_key_flip_experiment(
        key,
        key_prime,
        plaintext,
        enable_shiftrows=True,
        mixcolumns_matrix=MODIFIED_MIXCOLUMNS,
    )
    save_results(
        results_d_mod,
        "/Users/sweeden/crypto_proj/AES_Experiment/results_part_d_modified.json",
    )
    print("Saved to results_part_d_modified.json")

    print("\n" + "=" * 60)
    print("All experiments complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
