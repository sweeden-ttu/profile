# AES Cryptanalysis Experiment Results
## CS 6343 - Spring 2026

---

## Experiment Summary

### Part A: Standard AES Avalanche Effect

| Round | Byte Hamming | Bit Hamming | Byte % | Bit % |
|-------|-------------|-------------|--------|-------|
| 0 | 1/16 | 1/128 | 6.2% | 0.8% |
| 1 | 4/16 | 17/128 | 25.0% | 13.3% |
| 2 | 16/16 | 49/128 | 100.0% | 38.3% |
| 3 | 16/16 | 62/128 | 100.0% | 48.4% |
| 4 | 16/16 | 73/128 | 100.0% | 57.0% |
| 5-10 | 16/16 | 54-63/128 | 100% | 43-49% |

**Observations:**
- Round 0: Only 1 bit changed (AddRoundKey XOR with single bit flip)
- Round 1-2: Rapid increase in diffusion as SubBytes, ShiftRows, MixColumns propagate change
- Round 3+: Full avalanche achieved (~50% bits flipped)
- Confirms: **HYPOTHESIS VALIDATED** - Standard AES exhibits proper avalanche effect

---

### Part B: No ShiftRows

| Round | Byte Hamming | Bit Hamming | Byte % | Bit % |
|-------|-------------|-------------|--------|-------|
| 0 | 1/16 | 1/128 | 6.2% | 0.8% |
| 1 | 4/16 | 17/128 | 25.0% | 13.3% |
| 2-10 | 4/16 | 11-20/128 | 25.0% | 8-15% |

**Observations:**
- Maximum diffusion: 4 bytes (25%) - confined to same column
- Bit flip never exceeds 20/128 (15.6%)
- Without ShiftRows, MixColumns can only affect bytes within same column
- Confirms: **HYPOTHESIS VALIDATED** - ShiftRows is critical for cross-column diffusion

---

### Part C: Modified MixColumns Matrix

| Round | Byte Hamming | Bit Hamming | Byte % | Bit % |
|-------|-------------|-------------|--------|-------|
| 0-10 | 1/16 | 1-6/128 | 6.2% | 0.8-4.7% |

**Observations:**
- Almost NO diffusion throughout all rounds
- Only 1 byte changed in the entire encryption
- The sparse matrix `[0x01,0x01,0x00,0x00; ...]` provides minimal mixing
- Each byte only influences itself and immediate neighbor
- Confirms: **HYPOTHESIS VALIDATED** - Standard MixColumns matrix is essential for strong diffusion
- **Security Implication**: The modified matrix would be cryptographically weak

---

### Part D: Key Bit Flip vs Plaintext Bit Flip

Results show similar patterns between:
- Standard AES with plaintext flip (Part A)
- Standard AES with key flip (Part D)

**Observations:**
- Both achieve full avalanche by round 3-4
- Similar bit percentages at each round
- Confirms: **HYPOTHESIS VALIDATED** - AddRoundKey is symmetric for key/plaintext XOR

---

## Conclusions

### Key Findings

1. **Avalanche Effect (Part A)**: AES achieves ~50% bit change by round 3, confirming the avalanche property. The combination of SubBytes, ShiftRows, and MixColumns provides effective diffusion.

2. **ShiftRows Role (Part B)**: Disabling ShiftRows severely limits diffusion to 25% byte change (confined to single column). This confirms ShiftRows provides critical cross-column diffusion.

3. **MixColumns Role (Part C)**: The modified sparse matrix essentially eliminates diffusion. This demonstrates the critical importance of the full MixColumns matrix for AES security.

4. **Key vs Plaintext (Part D)**: Key bit flips and plaintext bit flips produce equivalent diffusion patterns, confirming the symmetric nature of AddRoundKey.

### Security Implications

- Removing either ShiftRows or proper MixColumns would severely weaken AES
- The standard MixColumns matrix is essential for proper diffusion
- AES design is well-justified: each component serves a critical security function

---

## Files

- `aes_cryptanalysis.py` - Main AES implementation with configurable components
- `aes_modes_experiment.py` - ECB vs CBC mode comparison (requires Secret.bmp)
- `run_experiments.py` - Automated experiment runner
- `results_part_a.json` - Part A raw results
- `results_part_b.json` - Part B raw results
- `results_part_c.json` - Part C raw results
- `results_part_d_*.json` - Part D raw results
- `experiment_summary.txt` - Text summary of results
